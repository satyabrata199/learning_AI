# Planner · Multi-ReAct · Agent

A production-grade Planner → Executor multi-agent system with a Streamlit UI.

## Architecture

```
User Input
    │
    ▼
PlannerAgent        ← smallthinker:3b  (generates JSON plan)
    │
    ▼
ExecutorAgent       ← qwen2.5-coder:3b (ReAct loop, step by step)
    │
    ├── calculator       (math expressions)
    ├── web_search       (DuckDuckGo)
    ├── get_datetime     (current date/time)
    ├── save_note        (persist notes)
    ├── read_notes       (read saved notes)
    ├── word_count       (text stats)
    ├── text_transform   (upper/lower/title/reverse)
    ├── unit_converter   (km↔miles, °C↔°F, kg↔lbs, ...)
    ├── summarize_text   (extractive summary)
    ├── json_formatter   (pretty-print JSON)
    └── writer_agent     ← llama3.2:latest (writes emails, docs, notes)
```

## Setup

### 1. Install Ollama
```bash
# macOS / Linux
curl -fsSL https://ollama.com/install.sh | sh

# Windows: https://ollama.com/download
```

### 2. Pull models
```bash
ollama pull smallthinker:3b
ollama pull qwen2.5-coder:3b
ollama pull llama3.2:latest
```

### 3. Install Python deps
```bash
pip install -r requirements.txt
```

### 4. Run
```bash
streamlit run app.py
```

Open **http://localhost:8501** in your browser.

## Bug Fixes (vs original)

| File | Bug | Fix |
|---|---|---|
| `writer_agent.py` | `llm()` had no `return` statement | Added `return resp.json()["response"]` in llm_client |
| `writer_agent.py` | Output passed through `parse_llm_json` (wrong for plain text) | Returns raw LLM text directly |
| `execuaterAgent.py` | `input` (Python builtin) used instead of `ainp` in history string | Renamed to `ainp` throughout |
| `execuaterAgent.py` | Debug prints only inside `web_search` branch | Moved to every step via generator |
| `execuaterAgent.py` | No way to stream steps to UI | Converted to `Generator` that yields step dicts |
| `tools.py` | `from ddgs import DDGS` (wrong package name) | Tries both `duckduckgo_search` and `ddgs`, falls back gracefully |
| All agents | Models hardcoded, no config | All models configurable via Streamlit sidebar |

## Project Structure

```
agent_app/
├── app.py              ← Streamlit UI (main entry point)
├── agent.py            ← Orchestrator (planner → executor pipeline)
├── planner_agent.py    ← Generates JSON execution plan
├── executor_agent.py   ← ReAct executor (step-by-step, yields events)
├── writer_agent.py     ← Writing-focused sub-agent
├── tools.py            ← All 10 tools + TOOL_REGISTRY
├── llm_client.py       ← Ollama HTTP client (abstracted)
├── parse_llm_json.py   ← Robust JSON extractor
└── requirements.txt
```
