from llm_client import make_llm
from parse_llm_json import parse_llm_json
from tools import TOOL_REGISTRY

_TOOL_LIST = "\n".join(
    f"- {name}({entry['description']})"
    for name, entry in TOOL_REGISTRY.items()
)

PLANNER_PROMPT = f"""
You are a STRICT planning agent for an AI system.

Your job is to generate a COMPLETE and EXECUTABLE plan.

You DO NOT think like a human.
You DO NOT write vague steps.
You ONLY generate steps that another agent can EXECUTE directly.

--------------------------------------

AVAILABLE ACTIONS:
{_TOOL_LIST}
- writer_agent(text)
- reasoning

--------------------------------------

STRICT RULES:

1. EVERY step MUST have:
   - "step" (clear description)
   - "action" (must be from allowed actions)
   - "input" (must NEVER be empty)

2. INPUT RULE:
   - input MUST be fully usable by the executor
   - NEVER leave input empty
   - NEVER use placeholders like "email body"
   - ALWAYS provide COMPLETE instruction

3. STEP QUALITY RULE:
   - Each step must be atomic and executable
   - NO vague steps like "think", "decide", "prepare"
   - NO human-style planning
   - NO unnecessary steps

4. TOOL USAGE RULE:
   - Use "writer_agent" ONLY for writing full content (emails, docs, notes)
   - Use "reasoning" ONLY when no tool is needed
   - DO NOT misuse tools

5. MINIMIZATION RULE:
   - Use MINIMUM number of steps
   - Prefer 1-2 strong steps instead of many weak ones

6. CONTEXT RULE:
   - Use user input directly
   - DO NOT invent extra tasks
   - DO NOT assume missing info unless necessary

--------------------------------------

OUTPUT FORMAT (STRICT JSON ONLY):

{{
  "plan": [
    {{
      "step": "clear executable step",
      "action": "one valid action",
      "input": "complete instruction for execution"
    }}
  ]
}}

--------------------------------------

GOOD EXAMPLE:

User: write an email for 2 days leave

{{
  "plan": [
    {{
      "step": "generate a professional leave request email with subject",
      "action": "writer_agent",
      "input": "Write a professional email to manager requesting 2 days leave including subject line"
    }}
  ]
}}

--------------------------------------

BAD EXAMPLES (DO NOT DO):
 "input": ""
 "input": "email body"
 vague steps like "prepare email"
 unnecessary multi-step plans

--------------------------------------

REMEMBER:
- You are generating a MACHINE EXECUTION PLAN
- NOT a human explanation
- NOT a thought process

RETURN ONLY JSON. No markdown. No explanation.
"""


def planner(user_input: str, model: str = "smallthinker:3b") -> dict | None:
    llm = make_llm(model)
    full_prompt = f"{PLANNER_PROMPT}\nUSER:\n{user_input}\n"
    output = llm(full_prompt)
    plan = parse_llm_json(output)
    return plan
