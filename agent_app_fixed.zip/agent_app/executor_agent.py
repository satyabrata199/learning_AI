from typing import Generator
from llm_client import make_llm
from parse_llm_json import parse_llm_json
from tools import run_tool, TOOL_REGISTRY
from writer_agent import writer_agent

EXECUTOR_PROMPT = """
You are an EXECUTION AGENT.

Your job is to EXECUTE a given plan step-by-step using available tools.

You DO NOT create plans.
You DO NOT think about new steps.
You ONLY execute the CURRENT step.

--------------------------------------

AVAILABLE TOOLS:
{tool_list}
- writer_agent(text)
- finish

--------------------------------------

INPUT YOU RECEIVE:
1. Full execution plan
2. Previous observations (history)
3. Latest observation

--------------------------------------

YOUR RESPONSIBILITY:

For EACH step:
1. Read the step carefully
2. Decide the correct action
3. Execute ONLY that step
4. Return the result as JSON

--------------------------------------

STRICT RULES:

1. EXECUTION ONLY:
   - Do NOT modify the plan
   - Do NOT skip steps
   - Do NOT add steps

2. ONE STEP AT A TIME:
   - Only execute CURRENT step
   - Do NOT simulate future steps

3. TOOL USAGE:
   - Use EXACT action given in the step
   - Pass input EXACTLY (or minimally improved if needed)

4. CONTEXT USAGE:
   - Use previous observations if required
   - If step says "use previous result", use the latest observation

5. WRITER AGENT RULE:
   - If action = writer_agent → generate FULL content
   - Do NOT return partial text

6. ERROR HANDLING:
   - If step is unclear → return reasoning
   - If tool fails → return error observation

--------------------------------------

OUTPUT FORMAT (STRICT JSON, NO MARKDOWN):

{{
  "thought": "what you are doing in this step",
  "action": "tool_name or finish",
  "input": "input used",
  "observation": "result of execution or empty string"
}}

--------------------------------------

SPECIAL RULE:

If ALL steps are done → return:

{{
  "thought": "I have completed all steps",
  "action": "finish",
  "input": "final answer or result"
}}

--------------------------------------

IMPORTANT:
- Be precise and deterministic
- No explanations outside JSON
- No markdown
- No extra text
"""


def _build_tool_list() -> str:
    return "\n".join(
        f"- {name}: {entry['description']}"
        for name, entry in TOOL_REGISTRY.items()
    )


def executor(
    plan: dict,
    model: str = "qwen2.5-coder:3b",
    max_steps: int = 12,
) -> Generator[dict, None, None]:
    """
    Executes a plan step by step.

    BUGS FIXED vs original:
    - `input` (builtin) used instead of `ainp` in history → fixed
    - print/debug after only web_search branch → moved correctly
    - writer_agent called parse_llm_json on plain text → fixed
    - llm() had no return statement → fixed in llm_client
    - No generator: UI had no way to stream steps → now yields dicts

    Yields dict per step:
      {"step": int, "thought": str, "action": str, "input": str, "observation": str, "status": "running"|"done"|"error"}
    """
    llm = make_llm(model)
    tool_list = _build_tool_list()
    prompt_base = EXECUTOR_PROMPT.format(tool_list=tool_list)

    history = []
    observation = ""

    for step_num in range(1, max_steps + 1):
        history_text = "\n".join(
            f"Step {h['step']}: [{h['action']}] {h['input']} → {h['observation']}"
            for h in history
        )

        full_prompt = f"""
{prompt_base}

Execution plan:
{plan}

Previous steps:
{history_text or '(none yet)'}

Latest observation:
{observation or '(none)'}

Now give ONLY the next step as JSON.
"""
        raw = llm(full_prompt)
        action_data = parse_llm_json(raw)

        if action_data is None:
            yield {
                "step": step_num,
                "thought": "Failed to parse LLM output",
                "action": "error",
                "input": "",
                "observation": f"Parse error on: {repr(raw[:200])}",
                "status": "error",
            }
            return

        thought = action_data.get("thought", "")
        action = action_data.get("action", "").strip()
        ainp = action_data.get("input", "")

        # ------------------------------------------------------------------ #
        # Execute action
        # ------------------------------------------------------------------ #
        if action == "finish":
            yield {
                "step": step_num,
                "thought": thought,
                "action": "finish",
                "input": ainp,
                "observation": ainp,
                "status": "done",
            }
            return

        elif action == "writer_agent":
            observation = writer_agent(ainp, model="llama3.2:latest")

        elif action in TOOL_REGISTRY:
            observation = run_tool(action, ainp)

        elif action == "reasoning":
            observation = ainp or thought

        else:
            observation = f"Unknown action '{action}' — skipping."

        step_event = {
            "step": step_num,
            "thought": thought,
            "action": action,
            "input": ainp,
            "observation": observation,
            "status": "running",
        }
        yield step_event

        history.append(step_event)

    # Exhausted max steps
    yield {
        "step": max_steps,
        "thought": "Max steps reached",
        "action": "finish",
        "input": observation,
        "observation": observation,
        "status": "done",
    }
