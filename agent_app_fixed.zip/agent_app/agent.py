from typing import Generator
from planner_agent import planner
from executor_agent import executor


def base_agent(
    user_input: str,
    planner_model: str = "smallthinker:3b",
    executor_model: str = "qwen2.5-coder:3b",
    max_steps: int = 12,
) -> Generator[dict, None, None]:
    """
    Full pipeline: plan → execute.
    Yields events: {"type": "plan"|"step"|"result"|"error", ...}
    """
    # 1. Plan
    try:
        plan = planner(user_input, model=planner_model)
    except RuntimeError as e:
        yield {"type": "error", "message": str(e)}
        return

    if plan is None:
        yield {"type": "error", "message": "Planner returned no valid plan. Check your model."}
        return

    yield {"type": "plan", "plan": plan}

    # 2. Execute
    final_result = None
    try:
        for step_event in executor(plan, model=executor_model, max_steps=max_steps):
            yield {"type": "step", **step_event}
            if step_event["status"] in ("done", "error"):
                final_result = step_event["observation"]
                break
    except RuntimeError as e:
        yield {"type": "error", "message": str(e)}
        return

    yield {"type": "result", "result": final_result or "No result returned."}
