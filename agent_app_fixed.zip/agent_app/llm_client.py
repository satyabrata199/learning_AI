import requests
import json
from typing import Callable

OLLAMA_URL = "http://localhost:11434/api/generate"


def make_llm(model: str, url: str = OLLAMA_URL) -> Callable[[str], str]:
    """
    Returns an LLM callable for the given Ollama model.
    Streams=False; raises on HTTP error.
    """
    def call(prompt: str) -> str:
        try:
            resp = requests.post(
                url,
                json={"model": model, "prompt": prompt, "stream": False},
                timeout=120,
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("response", "")
        except requests.exceptions.ConnectionError:
            raise RuntimeError(
                f"Cannot connect to Ollama at {url}. "
                "Make sure Ollama is running:  ollama serve"
            )
        except requests.exceptions.Timeout:
            raise RuntimeError(f"Ollama timed out (model={model}). Try a smaller model.")
        except Exception as e:
            raise RuntimeError(f"LLM call failed ({model}): {e}")
    return call
