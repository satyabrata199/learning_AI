import math
import os
import json
from datetime import datetime

# ---------------------------------------------------------------------------
# Try importing optional deps; fall back gracefully
# ---------------------------------------------------------------------------
try:
    from duckduckgo_search import DDGS
    _DDGS_AVAILABLE = True
except ImportError:
    try:
        from ddgs import DDGS
        _DDGS_AVAILABLE = True
    except ImportError:
        _DDGS_AVAILABLE = False


# ---------------------------------------------------------------------------
# Core tools
# ---------------------------------------------------------------------------

def get_datetime(_=None) -> str:
    now = datetime.now()
    return (
        f"Current date: {now.strftime('%A, %B %d, %Y')}  |  "
        f"Time: {now.strftime('%I:%M %p')}  |  "
        f"Day of week: {now.strftime('%A')}"
    )


def calculator(expression: str) -> str:
    """Safe math evaluator with extended math functions."""
    try:
        safe_globals = {k: getattr(math, k) for k in dir(math) if not k.startswith("_")}
        safe_globals.update({"abs": abs, "round": round, "min": min, "max": max,
                              "sum": sum, "pow": pow, "int": int, "float": float})
        result = eval(expression, {"__builtins__": {}}, safe_globals)
        return str(result)
    except ZeroDivisionError:
        return "Error: division by zero"
    except Exception as e:
        return f"Calculator error: {e}"


def web_search(query: str) -> str:
    """Search the web using DuckDuckGo."""
    if not _DDGS_AVAILABLE:
        return "web_search unavailable: install duckduckgo-search  →  pip install duckduckgo-search"
    try:
        results = []
        with DDGS() as ddgs:
            for r in ddgs.text(query, max_results=5):
                results.append(f"• {r['title']}\n  {r['body']}\n  Source: {r.get('href','')}")
        return "\n\n".join(results) if results else "No results found."
    except Exception as e:
        return f"Search error: {e}"


def save_note(note: str) -> str:
    """Append a timestamped note to notes.txt."""
    try:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open("notes.txt", "a", encoding="utf-8") as f:
            f.write(f"[{ts}] {note}\n")
        return f"Note saved at {ts}"
    except Exception as e:
        return f"Save error: {e}"


def read_notes(_=None) -> str:
    """Read all saved notes."""
    try:
        if not os.path.exists("notes.txt"):
            return "No notes saved yet."
        with open("notes.txt", "r", encoding="utf-8") as f:
            content = f.read().strip()
        return content if content else "Notes file is empty."
    except Exception as e:
        return f"Read error: {e}"


# ---------------------------------------------------------------------------
# Extra tools
# ---------------------------------------------------------------------------

def word_count(text: str) -> str:
    """Count words, characters and sentences in text."""
    words = len(text.split())
    chars = len(text)
    chars_no_space = len(text.replace(" ", ""))
    sentences = text.count(".") + text.count("!") + text.count("?")
    paragraphs = len([p for p in text.split("\n\n") if p.strip()])
    return (
        f"Words: {words} | Characters: {chars} | "
        f"Characters (no spaces): {chars_no_space} | "
        f"Sentences: {sentences} | Paragraphs: {paragraphs}"
    )


def text_transform(instruction: str) -> str:
    """
    Transform text.  instruction format:  <mode>|<text>
    Modes: upper, lower, title, reverse, capitalize
    Example:  upper|hello world
    """
    try:
        if "|" not in instruction:
            return "Format: <mode>|<text>  e.g.  upper|hello world"
        mode, text = instruction.split("|", 1)
        mode = mode.strip().lower()
        transforms = {
            "upper": text.upper,
            "lower": text.lower,
            "title": text.title,
            "reverse": lambda: text[::-1],
            "capitalize": text.capitalize,
            "strip": text.strip,
        }
        if mode not in transforms:
            return f"Unknown mode '{mode}'. Available: {', '.join(transforms)}"
        return transforms[mode]()
    except Exception as e:
        return f"Transform error: {e}"


def unit_converter(instruction: str) -> str:
    """
    Convert units.  instruction format:  <value> <from_unit> to <to_unit>
    Supported: km/miles, kg/lbs, celsius/fahrenheit, meters/feet, liters/gallons
    Example:  100 km to miles
    """
    try:
        import re
        m = re.match(r"([\d.]+)\s*(\w+)\s+to\s+(\w+)", instruction.strip(), re.I)
        if not m:
            return "Format: <value> <from> to <to>  e.g.  100 km to miles"
        val, frm, to = float(m.group(1)), m.group(2).lower(), m.group(3).lower()

        conversions = {
            ("km", "miles"): val * 0.621371,
            ("miles", "km"): val * 1.60934,
            ("kg", "lbs"): val * 2.20462,
            ("lbs", "kg"): val * 0.453592,
            ("celsius", "fahrenheit"): val * 9/5 + 32,
            ("fahrenheit", "celsius"): (val - 32) * 5/9,
            ("meters", "feet"): val * 3.28084,
            ("feet", "meters"): val * 0.3048,
            ("liters", "gallons"): val * 0.264172,
            ("gallons", "liters"): val * 3.78541,
            ("cm", "inches"): val * 0.393701,
            ("inches", "cm"): val * 2.54,
        }
        key = (frm, to)
        if key not in conversions:
            return f"Conversion '{frm}' → '{to}' not supported."
        result = conversions[key]
        return f"{val} {frm} = {round(result, 4)} {to}"
    except Exception as e:
        return f"Converter error: {e}"


def summarize_text(text: str) -> str:
    """
    Extract key sentences from text as a simple extractive summary.
    Returns the first 3 sentences as a quick summary.
    """
    import re
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
    if not sentences:
        return "Not enough text to summarize."
    summary = " ".join(sentences[:3])
    return f"Summary ({len(sentences)} sentences → 3): {summary}"


def json_formatter(raw: str) -> str:
    """Pretty-print a JSON string."""
    try:
        parsed = json.loads(raw)
        return json.dumps(parsed, indent=2, ensure_ascii=False)
    except Exception as e:
        return f"JSON format error: {e}"


# ---------------------------------------------------------------------------
# Tool registry  (used by executor and Streamlit UI)
# ---------------------------------------------------------------------------

TOOL_REGISTRY = {
    "calculator": {
        "fn": calculator,
        "description": "Evaluate math expressions. Supports +, -, *, /, **, sqrt, sin, cos, log, etc.",
        "example": "2 ** 10 + sqrt(144)",
        "emoji": "🧮",
    },
    "web_search": {
        "fn": web_search,
        "description": "Search the web with DuckDuckGo and return top results.",
        "example": "latest news about AI 2025",
        "emoji": "🌐",
    },
    "get_datetime": {
        "fn": get_datetime,
        "description": "Get the current date, time and day of week.",
        "example": "(no input needed)",
        "emoji": "🕐",
    },
    "save_note": {
        "fn": save_note,
        "description": "Save a timestamped note to notes.txt.",
        "example": "Remember to review the project on Friday",
        "emoji": "📝",
    },
    "read_notes": {
        "fn": read_notes,
        "description": "Read all previously saved notes.",
        "example": "(no input needed)",
        "emoji": "📖",
    },
    "word_count": {
        "fn": word_count,
        "description": "Count words, characters, sentences, and paragraphs in any text.",
        "example": "The quick brown fox jumps over the lazy dog.",
        "emoji": "🔢",
    },
    "text_transform": {
        "fn": text_transform,
        "description": "Transform text: upper, lower, title, reverse, capitalize. Format: mode|text",
        "example": "title|the quick brown fox",
        "emoji": "✏️",
    },
    "unit_converter": {
        "fn": unit_converter,
        "description": "Convert units: km/miles, kg/lbs, celsius/fahrenheit, meters/feet, liters/gallons.",
        "example": "100 km to miles",
        "emoji": "🔁",
    },
    "summarize_text": {
        "fn": summarize_text,
        "description": "Extractive summary: returns the top 3 key sentences from long text.",
        "example": "Paste a long article or paragraph here...",
        "emoji": "📋",
    },
    "json_formatter": {
        "fn": json_formatter,
        "description": "Pretty-print a JSON string with proper indentation.",
        "example": '{"name":"Alice","age":30}',
        "emoji": "📦",
    },
}


def run_tool(name: str, inp: str) -> str:
    """Execute a tool by name. Returns result string."""
    entry = TOOL_REGISTRY.get(name)
    if not entry:
        return f"Unknown tool: '{name}'. Available: {', '.join(TOOL_REGISTRY)}"
    try:
        return str(entry["fn"](inp))
    except Exception as e:
        return f"Tool '{name}' error: {e}"
