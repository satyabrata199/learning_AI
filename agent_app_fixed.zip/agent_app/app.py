import streamlit as st
import sys
import os
import time

# Make sure local modules are importable
sys.path.insert(0, os.path.dirname(__file__))

from tools import TOOL_REGISTRY, run_tool

# ─────────────────────────────────────────────────────────────────────────────
# Page config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ReAct Agent",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
# Custom CSS
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;600;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
}

/* Dark sidebar */
section[data-testid="stSidebar"] {
    background: #0f0f14;
    border-right: 1px solid #1e1e2e;
}

/* Main background */
.stApp {
    background: #0d0d12;
    color: #e0e0f0;
}

/* Step cards */
.step-card {
    background: #13131a;
    border: 1px solid #2a2a40;
    border-left: 3px solid #7c6af7;
    border-radius: 8px;
    padding: 14px 18px;
    margin: 8px 0;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.82rem;
}

.step-card.done {
    border-left-color: #4ade80;
}

.step-card.error {
    border-left-color: #f87171;
}

.step-card .label {
    font-size: 0.65rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #7c6af7;
    margin-bottom: 2px;
}

.step-card.done .label { color: #4ade80; }
.step-card.error .label { color: #f87171; }

.result-box {
    background: #0b1a14;
    border: 1px solid #4ade80;
    border-radius: 10px;
    padding: 20px;
    margin-top: 16px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.85rem;
    white-space: pre-wrap;
    line-height: 1.6;
    color: #d4fae8;
}

.plan-card {
    background: #0f0f1e;
    border: 1px solid #3a3a6e;
    border-radius: 8px;
    padding: 12px 16px;
    margin: 6px 0;
    font-size: 0.83rem;
}

.plan-step-num {
    display: inline-block;
    background: #7c6af7;
    color: white;
    border-radius: 50%;
    width: 22px;
    height: 22px;
    text-align: center;
    line-height: 22px;
    font-size: 0.72rem;
    font-weight: 600;
    margin-right: 8px;
}

.action-badge {
    display: inline-block;
    background: #1a1a35;
    border: 1px solid #7c6af7;
    color: #a89cf5;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.72rem;
    font-family: 'JetBrains Mono', monospace;
    margin-left: 6px;
}

.tool-card {
    background: #13131a;
    border: 1px solid #2a2a40;
    border-radius: 8px;
    padding: 12px 14px;
    margin: 6px 0;
}

.error-box {
    background: #1a0d0d;
    border: 1px solid #f87171;
    border-radius: 8px;
    padding: 14px;
    color: #fca5a5;
    font-size: 0.85rem;
    font-family: 'JetBrains Mono', monospace;
}

.model-chip {
    display: inline-block;
    background: #1e1e35;
    border: 1px solid #4a4a80;
    color: #a0a0cc;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 0.72rem;
    font-family: 'JetBrains Mono', monospace;
}

h1, h2, h3 { font-family: 'Syne', sans-serif !important; }

.stTextInput input, .stTextArea textarea, .stSelectbox select {
    background: #13131a !important;
    border: 1px solid #2a2a40 !important;
    color: #e0e0f0 !important;
    font-family: 'JetBrains Mono', monospace !important;
}

.stButton > button {
    background: linear-gradient(135deg, #7c6af7, #5b4de0);
    color: white;
    border: none;
    border-radius: 8px;
    font-family: 'Syne', sans-serif;
    font-weight: 600;
    padding: 10px 24px;
    transition: all 0.2s;
}

.stButton > button:hover {
    background: linear-gradient(135deg, #9b8df9, #7c6af7);
    transform: translateY(-1px);
}

div[data-testid="metric-container"] {
    background: #13131a;
    border: 1px solid #2a2a40;
    border-radius: 8px;
    padding: 10px;
}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# Session state init
# ─────────────────────────────────────────────────────────────────────────────
if "history" not in st.session_state:
    st.session_state.history = []   # list of {query, plan, steps, result, error}
if "running" not in st.session_state:
    st.session_state.running = False


# ─────────────────────────────────────────────────────────────────────────────
# Sidebar
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")
    st.markdown("---")

    planner_model = st.text_input(
        "Planner Model", value="smallthinker:3b",
        help="Ollama model name for planning"
    )
    executor_model = st.text_input(
        "Executor Model", value="qwen2.5-coder:3b",
        help="Ollama model name for execution"
    )
    writer_model = st.text_input(
        "Writer Model", value="llama3.2:latest",
        help="Ollama model name for writing tasks"
    )
    max_steps = st.slider("Max Steps", 1, 20, 12)

    st.markdown("---")
    st.markdown("## 🧰 Available Tools")

    for name, meta in TOOL_REGISTRY.items():
        with st.expander(f"{meta['emoji']} `{name}`"):
            st.markdown(f"**{meta['description']}**")
            st.markdown(f"*Example:* `{meta['example']}`")

    st.markdown("---")
    st.markdown("## 🔧 Direct Tool Test")
    tool_name = st.selectbox("Tool", list(TOOL_REGISTRY.keys()))
    tool_input = st.text_input("Input", value=TOOL_REGISTRY[tool_name]["example"])
    if st.button("▶ Run Tool"):
        with st.spinner("Running..."):
            result = run_tool(tool_name, tool_input)
        st.code(result, language="text")

    st.markdown("---")
    if st.button("🗑️ Clear History"):
        st.session_state.history = []
        st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# Header
# ─────────────────────────────────────────────────────────────────────────────
col_h1, col_h2 = st.columns([3, 1])
with col_h1:
    st.markdown("# 🤖 Planner · ReAct · Multi-Agent")
    st.markdown(
        "A production-grade **Planner → Executor** agent with "
        "structured step-by-step reasoning and 10 built-in tools."
    )
with col_h2:
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown(
        f'<span class="model-chip">planner: {planner_model}</span> '
        f'<span class="model-chip">exec: {executor_model}</span>',
        unsafe_allow_html=True,
    )

st.markdown("---")

# ─────────────────────────────────────────────────────────────────────────────
# Input
# ─────────────────────────────────────────────────────────────────────────────
query = st.text_area(
    "💬 Your Task",
    placeholder=(
        "Examples:\n"
        "• What is 15% of 847?\n"
        "• Write a professional email requesting a meeting\n"
        "• What time is it and convert 72°F to Celsius?\n"
        "• Search for latest Python 3.13 features\n"
        "• Count words in: The quick brown fox jumps over the lazy dog"
    ),
    height=110,
    label_visibility="visible",
)

col_run, col_ex = st.columns([2, 5])
with col_run:
    run_btn = st.button("🚀 Run Agent", disabled=st.session_state.running, use_container_width=True)
with col_ex:
    example = st.selectbox(
        "Quick examples",
        ["", "What is sqrt(144) + 15% of 200?",
         "Write a formal email to decline a meeting politely",
         "What is today's date and convert 100 km to miles?",
         "Search the web: what is LangGraph?",
         "Save note: Review the agent project tomorrow morning",
         "Count words: To be or not to be, that is the question"],
        label_visibility="collapsed",
    )
    if example and not st.session_state.running:
        query = example


# ─────────────────────────────────────────────────────────────────────────────
# Run agent
# ─────────────────────────────────────────────────────────────────────────────
if run_btn and query.strip():
    st.session_state.running = True
    st.markdown("---")
    st.markdown("### 🔄 Agent Execution")

    # Live output containers
    plan_container = st.empty()
    steps_container = st.container()
    result_container = st.empty()
    status_bar = st.empty()

    record = {
        "query": query.strip(),
        "plan": None,
        "steps": [],
        "result": None,
        "error": None,
        "model_p": planner_model,
        "model_e": executor_model,
    }

    try:
        from agent import base_agent
        start_time = time.time()

        for event in base_agent(
            query.strip(),
            planner_model=planner_model,
            executor_model=executor_model,
            max_steps=max_steps,
        ):
            etype = event.get("type")

            # ---- Plan ----
            if etype == "plan":
                record["plan"] = event["plan"]
                plan_steps = event["plan"].get("plan", [])
                plan_html = "<div style='margin-bottom:12px'><b>📋 Execution Plan</b></div>"
                for i, s in enumerate(plan_steps, 1):
                    plan_html += f"""
                    <div class="plan-card">
                        <span class="plan-step-num">{i}</span>
                        <b>{s.get('step','')}</b>
                        <span class="action-badge">{s.get('action','')}</span>
                        <div style="color:#888;font-size:0.78rem;margin-top:6px;margin-left:30px">
                            {s.get('input','')}
                        </div>
                    </div>"""
                plan_container.markdown(plan_html, unsafe_allow_html=True)

            # ---- Step ----
            elif etype == "step":
                record["steps"].append(event)
                status = event.get("status", "running")
                card_class = "step-card done" if status == "done" else (
                    "step-card error" if status == "error" else "step-card")

                elapsed = time.time() - start_time
                with steps_container:
                    st.markdown(f"""
                    <div class="{card_class}">
                        <div class="label">Step {event['step']} · {event['action']} · {elapsed:.1f}s</div>
                        <div style="color:#c0c0e0;margin:4px 0"><b>💭</b> {event.get('thought','')}</div>
                        <div style="color:#888;margin:2px 0"><b>📥</b> {event.get('input','')}</div>
                        <div style="color:#a0f0c0;margin:2px 0"><b>📤</b> {str(event.get('observation',''))[:400]}</div>
                    </div>""", unsafe_allow_html=True)
                status_bar.markdown(
                    f"⏳ Step {event['step']} / {max_steps} — `{event['action']}` — {elapsed:.1f}s elapsed"
                )

            # ---- Result ----
            elif etype == "result":
                record["result"] = event["result"]
                total = time.time() - start_time
                result_container.markdown(
                    f"<div class='result-box'>✅ <b>FINAL RESULT</b> ({total:.1f}s)\n\n"
                    f"{event['result']}</div>",
                    unsafe_allow_html=True,
                )
                status_bar.markdown(f"✅ Done in **{total:.1f}s** · {len(record['steps'])} steps")

            # ---- Error ----
            elif etype == "error":
                record["error"] = event["message"]
                result_container.markdown(
                    f"<div class='error-box'>❌ <b>ERROR</b>\n\n{event['message']}</div>",
                    unsafe_allow_html=True,
                )
                status_bar.markdown("❌ Agent encountered an error")

    except Exception as e:
        record["error"] = str(e)
        result_container.markdown(
            f"<div class='error-box'>❌ <b>Unexpected error</b>\n\n{e}</div>",
            unsafe_allow_html=True,
        )

    st.session_state.history.insert(0, record)
    st.session_state.running = False


# ─────────────────────────────────────────────────────────────────────────────
# History
# ─────────────────────────────────────────────────────────────────────────────
if st.session_state.history:
    st.markdown("---")
    st.markdown("### 📜 Session History")

    # Metrics
    total_runs = len(st.session_state.history)
    success = sum(1 for h in st.session_state.history if h.get("result"))
    errors = sum(1 for h in st.session_state.history if h.get("error"))
    total_steps = sum(len(h.get("steps", [])) for h in st.session_state.history)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Runs", total_runs)
    c2.metric("Successful", success)
    c3.metric("Errors", errors)
    c4.metric("Total Steps", total_steps)

    st.markdown("")

    for i, h in enumerate(st.session_state.history):
        icon = "✅" if h.get("result") else "❌"
        with st.expander(f"{icon} Run {i+1}: {h['query'][:80]}"):
            tabs = st.tabs(["Plan", "Steps", "Result"])

            with tabs[0]:
                if h.get("plan"):
                    for j, s in enumerate(h["plan"].get("plan", []), 1):
                        st.markdown(f"**{j}.** {s.get('step','')} — `{s.get('action','')}` — *{s.get('input','')}*")
                else:
                    st.info("No plan available")

            with tabs[1]:
                if h.get("steps"):
                    for s in h["steps"]:
                        st.markdown(f"**Step {s['step']}** `{s['action']}`")
                        st.markdown(f"- 💭 {s.get('thought','')}")
                        st.markdown(f"- 📥 `{s.get('input','')}`")
                        st.markdown(f"- 📤 {str(s.get('observation',''))[:300]}")
                        st.divider()
                else:
                    st.info("No steps recorded")

            with tabs[2]:
                if h.get("result"):
                    st.markdown(
                        f"<div class='result-box'>{h['result']}</div>",
                        unsafe_allow_html=True,
                    )
                elif h.get("error"):
                    st.markdown(
                        f"<div class='error-box'>{h['error']}</div>",
                        unsafe_allow_html=True,
                    )
                else:
                    st.info("No result")
